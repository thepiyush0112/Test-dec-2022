package com.springboot.controller;

import com.springboot.exception.NotFoundException;
import com.springboot.model.Book;
import com.springboot.service.BookService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

// class is acting as the controller.

@RestController
@RequestMapping("/book")
public class BookController {

  @Autowired
  BookService service;

  // endpoint - http://localhost:9800/book/id?key=1
  @GetMapping("/id")
  @ResponseStatus(HttpStatus.OK)
  public Book getBook(@RequestParam("key") int key) throws NotFoundException {
    return service.getBook(key);
  }

  // endpoint - http://localhost:9800/book/all
  @GetMapping("/all")
  @ResponseStatus(HttpStatus.OK)
  public List<Book> getBooks() {
    return service.getBooks();
  }

  // endpoint - http://localhost:9800/book/genre?type=Fable
  @GetMapping("/genre")
  @ResponseStatus(HttpStatus.OK)
  public List<Book> getBooksByGenre(@RequestParam("type") String type) {
    return service.getBooksByGenre(type);
  }

  // endpoint - http://localhost:9800/book/quantity?quantity=5
  @GetMapping("/quantity")
  @ResponseStatus(HttpStatus.OK)
  public List<Book> getBooksByQuantity(@RequestParam("quantity") int quantity) {
    return service.getBooksByQuantity(quantity);
  }
}
