package com.springboot.bootstrap;

import com.github.javafaker.Faker;
import com.springboot.model.Book;
import com.springboot.service.BookService;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

// class responsible to populate the sample data in the sql table on application startup.

//lombok
@Slf4j
//spring
@Component
public class Loader implements CommandLineRunner {

  private static final Faker FAKER = new Faker(Locale.ENGLISH);

  @Autowired
  BookService service;

  @Override
  public void run(String... args) {
    long total = service.getCount();
    log.info("Count={}", total);
    if (total > 0) {
      log.info("Skipping default save. Data already present");
    } else {
      service.save(prepareBooks());
    }
  }

  private List<Book> prepareBooks() {
    List<Book> books = new ArrayList<>();
    for (int i = 0; i < 10; i++) {
      books.add(randomBook());
    }
    return books;
  }

  private Book randomBook() {
    return Book.builder()
        .author(FAKER.book().author())
        .title(FAKER.book().title())
        .genre(FAKER.book().genre())
        .publisher(FAKER.book().publisher())
        .quantity(FAKER.number().randomDigit())
        .build();
  }
}
