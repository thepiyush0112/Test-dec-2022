package com.springboot;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//spring
@SpringBootApplication
public class TestContainersApp {

  public static void main(String[] args) {
    SpringApplication.run(TestContainersApp.class, args);
  }
}
