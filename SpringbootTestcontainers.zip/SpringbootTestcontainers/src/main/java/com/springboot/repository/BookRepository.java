package com.springboot.repository;

import com.springboot.model.Book;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

	// custom jpa method to find books by genre.
	List<Book> findBooksByGenre(String genre);

	// custom jpa method to find books by quantity.
	List<Book> findBooksByQuantityGreaterThanEqual(int quantity);

	// custom jpa method to find book by name.
	Book findFirstByTitle(String title);
}
