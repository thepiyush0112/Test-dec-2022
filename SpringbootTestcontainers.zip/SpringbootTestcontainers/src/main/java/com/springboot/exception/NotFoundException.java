package com.springboot.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

// If the entity is not found the sql table this exception will be thrown with a
// http 404 error response code.

@ResponseStatus(HttpStatus.NOT_FOUND)
public class NotFoundException extends Exception {

  static final long serialVersionUID = 1L;

  public NotFoundException(String msg) {
    super(msg);
  }
}
