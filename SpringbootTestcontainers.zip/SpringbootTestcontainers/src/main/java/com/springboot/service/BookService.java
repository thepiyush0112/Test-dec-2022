package com.springboot.service;

import com.springboot.exception.NotFoundException;
import com.springboot.model.Book;
import com.springboot.repository.BookRepository;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// dao abstraction layer.

@Service
@Slf4j
public class BookService {

  @Autowired
  BookRepository repository;

  public void save(List<Book> books) {
    log.info("Savings books");
    repository.saveAllAndFlush(books);
  }

  public long getCount() {
    return repository.count();
  }

  // method will throw the not found exception if the resource does not exists.
  public Book getBook(int key) throws NotFoundException {
    log.info("Searching book id={}", key);
    return repository.findById(key)
        .orElseThrow(() -> new NotFoundException(String.format("Book %s not found", key)));
  }

  public List<Book> getBooks() {
    log.info("Fetching all books");
    return repository.findAll();
  }

  public List<Book> getBooksByGenre(String type) {
    log.info("Searching books with genre={}", type);
    return repository.findBooksByGenre(type);
  }

  public List<Book> getBooksByQuantity(int quantity) {
    log.info("Searching books where quantity >= {}", quantity);
    return repository.findBooksByQuantityGreaterThanEqual(quantity);
  }
}
