package com.springboot.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

// entity table.

//lombok
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
//spring
@Entity
@Table(name = "book")
@Component
public class Book {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  int id;
  String author;
  String title;
  String genre;
  String publisher;
  int quantity;
}
