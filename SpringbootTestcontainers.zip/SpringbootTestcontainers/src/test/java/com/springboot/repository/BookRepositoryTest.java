package com.springboot.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.testcontainers.shaded.org.apache.commons.lang.RandomStringUtils.randomAlphabetic;

import com.github.javafaker.Faker;
import com.springboot.model.Book;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

// annotation is used to test the jpa repositories
// by default uses the embedded in-memory database for testing
@DataJpaTest
// annotation used to configure a test database instead of application
// defined or auto-configured datasource
@AutoConfigureTestDatabase(replace = Replace.NONE)
class BookRepositoryTest extends BaseIT {

  private static final Faker FAKER = new Faker(Locale.ENGLISH);

  @Autowired
  BookRepository objUnderTest;

  @Test
  void shouldFindBookById() {
    Book actual = create(randomAlphabetic(5), randomAlphabetic(5), 1);
    objUnderTest.saveAndFlush(actual);

    Book expected = objUnderTest.findById(actual.getId()).get();
    assertThat(expected).usingRecursiveComparison().isEqualTo(actual);
  }

  @Test
  void shouldFindBooksByGenre() {
    String genre = "Fable";
    List<Book> actual = prepare(2, randomAlphabetic(5), genre, 10);
    objUnderTest.saveAllAndFlush(actual);

    List<Book> expected = objUnderTest.findBooksByGenre(genre);
    assertThat(expected).usingRecursiveComparison().isEqualTo(actual);
  }

  @Test
  void shouldFindBooksByGenre_ReturnAnEmptyList() {
    List<Book> actual = prepare(2, randomAlphabetic(2), "Fiction", 1);
    objUnderTest.saveAllAndFlush(actual);

    assertThat(objUnderTest.findBooksByGenre(randomAlphabetic(5))).isEmpty();
  }

  @Test
  void shouldFindBooksByQuantity() {
    int quantity = 60;
    List<Book> actual = prepare(5, randomAlphabetic(5), randomAlphabetic(5), quantity);
    objUnderTest.saveAllAndFlush(actual);

    List<Book> expected = objUnderTest.findBooksByQuantityGreaterThanEqual(quantity);
    assertThat(expected).usingRecursiveComparison().isEqualTo(actual);
  }

  @Test
  void shouldFindBooksByQuantity_ReturnAnEmptyList() {
    List<Book> actual = prepare(2, randomAlphabetic(2), randomAlphabetic(5), 3);
    objUnderTest.saveAllAndFlush(actual);

    assertThat(objUnderTest.findBooksByQuantityGreaterThanEqual(50)).isEmpty();
  }

  @Test
  void shouldFindFirstBookByTitle() {
    Book book1 = create("Harry Potter", "Fantasy Fiction", 5);
    Book book2 = create("Harry Potter", "Fantasy Fiction", 10);
    List<Book> actual = Arrays.asList(book1, book2);
    objUnderTest.saveAllAndFlush(actual);

    assertThat(objUnderTest.findAll().size()).isEqualTo(2);

    Book expected = objUnderTest.findFirstByTitle("Harry Potter");
    assertThat(expected).usingRecursiveComparison().isEqualTo(book1);
  }

  //helper methods.

  private List<Book> prepare(int iterations, String title, String genre, int quantity) {
    List<Book> books = new ArrayList<>();
    for (int i = 0; i < iterations; i++) {
      books.add(create(title, genre, quantity));
    }
    return books;
  }

  private Book create(String title, String genre, int quantity) {
    return Book.builder()
        .author(FAKER.book().author())
        .title(title)
        .genre(genre)
        .publisher(FAKER.book().publisher())
        .quantity(quantity)
        .build();
  }
}
