package com.springboot.repository;

import org.testcontainers.containers.PostgreSQLContainer;

// using the singleton container approach to improve the performance of our tests.
public abstract class BaseIT {

  static PostgreSQLContainer<?> container;

  static {
    container = new PostgreSQLContainer<>("postgres:alpine")
        .withUsername("duke")
        .withPassword("password")
        .withDatabaseName("container")
        .withReuse(true);

    container.start();
  }
}
